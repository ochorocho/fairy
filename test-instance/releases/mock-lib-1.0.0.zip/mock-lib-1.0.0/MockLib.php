<?php

namespace MockVendor\MockLib;

/**
 * A mock FAIR package used for local testing of the FAIR Composer integration.
 */
class MockLib
{
    public function hello(): string
    {
        return 'Hello from mock-lib 1.0.0 installed via FAIR!';
    }
}
